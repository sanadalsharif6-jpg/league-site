(function(){
  // Small UX: preserve selected filters by scrolling to top after apply (optional)
  // Also adds subtle shimmer on hover via CSS-only; keep JS minimal to avoid performance issues.
})();